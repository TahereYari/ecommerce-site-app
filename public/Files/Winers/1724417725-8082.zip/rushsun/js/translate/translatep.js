const translations = {
    'en': {
        'p-t': 'zahra azizi',
        'po-t': 'profile',
        'p-s':'settings',
        'dash':'Dashboard',
        'pro':'Products',
        'f-p':'Products form',
        'f-u':'Users form',
        'm':'Competitions',
        'msg':'Messages',
        'support':'Support',
        'seti':'Setings',
        'up':'Update',
        'sc':'Security Update',
        'u-o':'Public Update',
        'u-k':' update',
        'new': 'New',
        'name': 'product name',
        'category':'category',
        'esh':'subscriptions',
        'buy': 'Buy',
        'product': 'Products',
        'license': 'Licenses name',
        'category-license': 'Category',
        'buy-license': 'Buy',
        'mf': 'Management',
        'licenses': 'Licenses',
        'users_': 'Users'
    },
    'fa': { 
        'p-t': 'زهرا عزیزی ',
        'po-t': 'پروفایل',
        'p-s':'تنطیمات',
        'dash':'داشبورد',
        'pro':'محصولات',
        'f-p':'فرم محصولات',
        'f-u':'فرم کاربران',
        'm':'مسابقات',
        'msg':'پیام ها',
        'support':'پشتیبانی',
        'seti':'تنطیمات',
        'up':'بروزرسانی',
        'sc':'بروزرسانی امنیتی',
        'u-o':'بروزرسانی عمومی',
        'u-k':'بروزرسانی کنید',
        'new':'جدید',
        'name': 'نام محصول',
        'category':'دسته بندی',
        'esh':'اشتراک ها',
        'buy': 'خرید',
        'product': 'محصولات',
        'license': 'نام لایسنس',
        'category-license' :'دسته بندی',
        'buy-license': 'خرید',
        'mf': 'فرم مدیریت',
        'licenses': 'لایسنس',
        'users_': 'کاربران'
    }
};

function switchLanguage(lang) {
    
    document.getElementById('p-t').textContent = translations[lang]['p-t'];
    document.getElementById('po-t').textContent = translations[lang]['po-t'];
    document.getElementById('p-s').textContent = translations[lang]['p-s'];
    document.getElementById('dash').textContent = translations[lang]['dash'];
    document.getElementById('pro').textContent = translations[lang]['pro'];
    document.getElementById('f-p').textContent = translations[lang]['f-p'];
    document.getElementById('f-u').textContent = translations[lang]['f-u'];
    document.getElementById('m').textContent = translations[lang]['m'];
    document.getElementById('msg').textContent = translations[lang]['msg'];
    document.getElementById('support').textContent = translations[lang]['support'];
    document.getElementById('seti').textContent = translations[lang]['seti'];
    document.getElementById('up').textContent = translations[lang]['up'];
    document.getElementById('sc').textContent = translations[lang]['sc'];
    document.getElementById('u-o').textContent = translations[lang]['u-o'];
    document.getElementById('u-k').textContent = translations[lang]['u-k'];
    document.getElementById('new').textContent = translations[lang]['new'];
    document.getElementById('name').textContent = translations[lang]['name'];
    document.getElementById('category').textContent = translations[lang]['category'];
    document.getElementById('esh').textContent = translations[lang]['esh'];
    document.getElementById('buy').textContent = translations[lang]['buy'];
    document.getElementById('product').textContent = translations[lang]['product'];
    document.getElementById('license').textContent = translations[lang]['license'];
    document.getElementById('category-license').textContent = translations[lang]['category-license'];
    document.getElementById('buy-license').textContent = translations[lang]['buy-license'];
    document.getElementById('mf').textContent = translations[lang]['mf'];
    document.getElementById('licenses').textContent = translations[lang]['licenses'];
    document.getElementById('users_').textContent = translations[lang]['users_'];


    document.documentElement.lang = lang;
    document.body.setAttribute('dir', lang === 'fa' ? 'rtl' : 'ltr');
}